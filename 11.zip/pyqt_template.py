# pyqt template
import sys
from PyQt5 import uic
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *


class MyApp(QWidget):  # QMainWindow 변경 필요
    def __init__(self):
        super(MyApp, self).__init__()
        self.initUI()

    def initUI(self):
        uic.loadUi('./ui/네이버영화 검색.ui', self)    # UI 파일 ㅣ변경필요
        # TODO 로직은 여기에 작성
        self.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = MyApp()
    app.exec_
